#include <cmath>
#include <iostream>
#include "Projetcpp2020.h" // dossier cpp


// toutes les fonctions en lien avec les tableau -------------------------------

/*
void AfficherTab(float *tab, int tailleTAB){
      float * p = tab ;
      int i ;
      for(i =0 ; i<tailleTAB ; i++ ){
        std::cout << *p << "\n" ;
        p++ ;
      }
    }


// fonctions en lien avec la classe vecteur ------------------------------------

// void Vecteur::affiche(){
//   AfficherTab(tab,dim) ;
//   std::cout << "la dimension du vecteur est : " << dim ;
// }


*/
