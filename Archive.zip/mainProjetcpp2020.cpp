# include <iostream>
# include <cmath>
# include "Projetcpp2020.h"


int main(int argc, char const *argv[]) {

  return 0 ;
}
