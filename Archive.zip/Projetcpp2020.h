
/*
// toutes les fonctions en lien avec les tableau ------------------------------

void AfficherTab(float *tab, int tailleTAB) ;


// fonctions en lien avec la classe vecteur------------------------------------

// tenseur d'ordre 1
// class Vecteur{
//   public:
//     float *tab ; // Allocation dynamique int * foo; foo = new int [5];
//     int dim ;
//   public:
// //  Vecteur() ; //constructeur
// //  Vecteur(float* ?) //constructeur
// // Vecteur(float*, int ?) //constructeur
//   void affiche() ; // affiche dim et les elements de tab
// //  deletvecteur(); // destructeur
// //  copievecteur(); // copie le vecteur
//   //surdefinition voir Projet
// } ;

*/
